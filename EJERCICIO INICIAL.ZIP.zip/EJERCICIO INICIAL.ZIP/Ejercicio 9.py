segundos=float(input("introduce un número en segunos para convertirlo en horas y minutos"))
minuto=segundos/60
horas=segundos/3600
print("son",minuto,"minutos")
print("son",horas,"horas")