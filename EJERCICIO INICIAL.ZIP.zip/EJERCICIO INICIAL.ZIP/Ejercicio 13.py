lado=float(input("introduce el valor numérico de un lado del volumen del cilindro"))
volumen=lado**3
area=6*lado**2
print("el volumen del cubo es:",volumen)
print("el área del cubo es:",area)
#Ejercicio 13: Calcular el volumen y área de un cubo (se proporciona la longitud de una arista).