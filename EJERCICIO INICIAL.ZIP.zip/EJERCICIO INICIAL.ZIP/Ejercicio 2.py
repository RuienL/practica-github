var1=int(input("introduce un número"))
var2=input("introduce una letra")
var3=float(input("introduce un número con decimal"))

print(var1)
print(var2)
print(var3)
