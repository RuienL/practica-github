var1=input(input("introduce un número"))
var2=input(input("introduce un número"))

print("el resultado es:",var1+var2)