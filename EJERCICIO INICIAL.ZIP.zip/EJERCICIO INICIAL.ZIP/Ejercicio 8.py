hora=float(input("introduce un número para convertirlo en segundos y minutos"))
minuto=hora*60
segundos=hora*3600
print("son",minuto,"minutos")
print("son",segundos,"segundos")
