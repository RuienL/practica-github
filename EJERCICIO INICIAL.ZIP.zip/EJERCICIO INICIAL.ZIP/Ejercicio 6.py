var1=input("introduce primera palabra")
var2=input("introduce segunda palabra")
var3=input("introduce tercera palabra")
var4=input("introduce cuarta palabra")
var5=input("introduce quinta palabra")

print(var1,var2,var3,var4,var5)
print(var5,var4,var3,var2,var1)