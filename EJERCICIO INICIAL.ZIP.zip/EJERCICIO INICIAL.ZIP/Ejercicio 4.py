var1=float(input("introduce un número"))
var2=float(input("introduce un número"))

print("el resultado es:",var1+var2)