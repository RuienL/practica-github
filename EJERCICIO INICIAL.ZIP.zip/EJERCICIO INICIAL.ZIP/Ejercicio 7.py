var1=float(input("introduce un número"))
var2=float(input("introduce un número"))

total1=var1+var2
total2=var1-var2
total3=var1*var2
total4=var1/var2
total5=var1%var2
total6=var1//var2
total7=var1**var2
divison2decimales=round(total4,2) #redondear 

print("la suma total es",total1)
print("la resta total es",total2)
print("la multiplicación total es",total3)
print("la división redondeada es",divison2decimales) #print redondeado
print("el modulo total es",total5)
print("la división entera total es",total6)
print("la potencia total es",total7)