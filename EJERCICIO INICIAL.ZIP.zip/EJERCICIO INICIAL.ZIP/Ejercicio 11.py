lado=float(input("introduce el valor numérico de un lado de un cuadrado"))
perimetro=lado*4
area=lado**2
print("el perímetro es de",perimetro)
print("el area es de",area)